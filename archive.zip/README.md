# linkedinlearning-learning-python
Learning python LinkedIn Learning course @ https://www.linkedin.com/learning/learning-python-2
